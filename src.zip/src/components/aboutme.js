import React, {Component} from 'react';



class aboutme extends Component {
    render() {
        return(
            <div> <h1> about me Page </h1></div>
        )
    }
}

export default aboutme;